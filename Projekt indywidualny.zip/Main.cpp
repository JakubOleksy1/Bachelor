#define _CRT_SECURE_NO_WARNINGS
#include "Arena.h"
#include <iostream>

int main()
{
	Arena a1;
	a1.rozpocznijGre();
}
