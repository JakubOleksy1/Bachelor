#pragma once

class Bron
{
private:

public:
	virtual int obrazenia(int __odleglosc) = 0;
};